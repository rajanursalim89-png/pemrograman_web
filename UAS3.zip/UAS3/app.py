from flask import Flask, render_template, request, redirect, url_for, flash
from datetime import datetime, timedelta
import math

app = Flask(__name__)
app.secret_key = "uas_parkir_final_fix_2026"

# Database Sementara (Akan terhapus jika server restart)
data_parkir = []
riwayat_masuk_detail = [] 
riwayat_pembayaran = [] 
BIAYA_PER_JAM = 2000

@app.route('/')
def index():
    now = datetime.now()
    filter_tgl = request.args.get('filter_tgl')
    hasil_filter = None
    
    if filter_tgl:
        hasil_filter = [r for r in riwayat_masuk_detail if r['waktu'].strftime('%Y-%m-%d') == filter_tgl]

    # Analisis Statistik
    total_pendapatan = sum(riwayat_pembayaran)
    masuk_hari_ini = sum(1 for r in riwayat_masuk_detail if r['waktu'].date() == now.date())
    masuk_minggu_ini = sum(1 for r in riwayat_masuk_detail if r['waktu'] >= now - timedelta(days=7))
    masuk_bulan_ini = sum(1 for r in riwayat_masuk_detail if r['waktu'].month == now.month and r['waktu'].year == now.year)
    masuk_tahun_ini = sum(1 for r in riwayat_masuk_detail if r['waktu'].year == now.year)

    analisis = {
        "pendapatan": total_pendapatan,
        "terisi": len(data_parkir),
        "total_transaksi": len(riwayat_pembayaran),
        "hari": masuk_hari_ini,
        "minggu": masuk_minggu_ini,
        "bulan": masuk_bulan_ini,
        "tahun": masuk_tahun_ini
    }

    return render_template('index.html', parkir=data_parkir, analisis=analisis, hasil_filter=hasil_filter, tgl_dicari=filter_tgl)

@app.route('/masuk', methods=['POST'])
def kendaraan_masuk():
    plat = request.form.get('plat').upper().strip()
    jenis = request.form.get('jenis').strip()
    merk = request.form.get('merk').strip()
    tgl_manual = request.form.get('tgl_masuk') 
    
    if plat and jenis and merk:
        if any(k['plat'] == plat for k in data_parkir):
            flash(f"Gagal: Kendaraan {plat} sudah ada di lokasi!", "error")
        else:
            # Jika tanggal manual diisi, gunakan itu. Jika kosong, gunakan waktu sekarang.
            if tgl_manual:
                waktu_skrg = datetime.strptime(tgl_manual, '%Y-%m-%dT%H:%M')
            else:
                waktu_skrg = datetime.now()

            data_parkir.append({"plat": plat, "jenis": jenis, "merk": merk, "waktu_masuk": waktu_skrg})
            riwayat_masuk_detail.append({"plat": plat, "merk": merk, "waktu": waktu_skrg})
            flash(f"Berhasil: {plat} masuk pada {waktu_skrg.strftime('%d-%m-%Y %H:%M')}", "success")
    return redirect(url_for('index'))

@app.route('/proses_keluar', methods=['POST'])
def proses_keluar():
    plat_keluar = request.form.get('plat_keluar').upper().strip()
    global data_parkir
    kendaraan = next((k for k in data_parkir if k['plat'] == plat_keluar), None)
    
    if kendaraan:
        durasi = datetime.now() - kendaraan['waktu_masuk']
        jam = math.ceil(durasi.total_seconds() / 3600)
        total_bayar = (jam if jam > 0 else 1) * BIAYA_PER_JAM
        
        riwayat_pembayaran.append(total_bayar)
        data_parkir = [k for k in data_parkir if k['plat'] != plat_keluar]
        flash(f"KELUAR BERHASIL! Plat: {plat_keluar} | Tarif: Rp{total_bayar:,}", "success")
    else:
        flash(f"Gagal: Plat {plat_keluar} tidak ditemukan!", "error")
    return redirect(url_for('index'))

if __name__ == '__main__':
    app.run(debug=True)